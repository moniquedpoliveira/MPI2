-- AlterTable
ALTER TABLE "ChecklistItem" ADD COLUMN     "observacao" TEXT;
