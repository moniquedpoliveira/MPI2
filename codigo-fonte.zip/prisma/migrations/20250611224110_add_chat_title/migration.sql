-- AlterTable
ALTER TABLE "Chat" ADD COLUMN     "title" TEXT;
