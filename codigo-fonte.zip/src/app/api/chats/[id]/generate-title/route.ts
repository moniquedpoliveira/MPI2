import { NextResponse } from 'next/server'
import { prisma } from '@/lib/prisma'
import { openai } from '@ai-sdk/openai'
import { generateText } from 'ai'

export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: chatId } = await params

    // Get the first user message from the chat
    const firstUserMessage = await prisma.message.findFirst({
      where: {
        chatId,
        role: 'user'
      },
      orderBy: {
        createdAt: 'asc'
      }
    })

    if (!firstUserMessage || !firstUserMessage.content) {
      return NextResponse.json(
        { error: 'No user message found to generate title from' },
        { status: 400 }
      )
    }

    // Use GPT-3.5-turbo for cheapest option
    const { text } = await generateText({
      model: openai('gpt-3.5-turbo'),
      prompt: `Generate a concise, descriptive title (max 50 characters) for a conversation that starts with: "${firstUserMessage.content}". Return only the title, no quotes or explanation.`,
      maxTokens: 20
    })

    // Update the chat with the generated title
    const updatedChat = await prisma.chat.update({
      where: { id: chatId },
      data: { title: text.trim() }
    })

    return NextResponse.json({ title: updatedChat.title })
  } catch (error) {
    console.error('Error generating chat title:', error)
    return NextResponse.json(
      { error: 'Failed to generate chat title' },
      { status: 500 }
    )
  }
} 