"server only";

import { LoginForm } from "./_components/login-form";

export default function LoginPage() {
  return <LoginForm />;
}
