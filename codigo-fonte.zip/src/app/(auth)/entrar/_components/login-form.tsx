"use client";

import { Button } from "@/components/ui/button";
import { Form } from "@/components/ui/form";
import {
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form-skeleton";
import { Input } from "@/components/ui/input";
import { signIn } from "@/lib/actions/auth";
import { zodResolver } from "@hookform/resolvers/zod";
import {
  IconLoader,
  IconMail,
  IconLock,
  IconCalendar,
  IconGauge,
} from "@tabler/icons-react";
import type React from "react";
import { useForm } from "react-hook-form";
import { toast } from "sonner";
import { z } from "zod";

const loginSchema = z.object({
  email: z.string().email("Por favor, insira um email válido"),
  password: z.string().min(6, "A senha deve ter pelo menos 6 caracteres"),
});

type LoginSchema = z.infer<typeof loginSchema>;

export const LoginForm: React.FC = () => {
  const form = useForm<LoginSchema>({
    resolver: zodResolver(loginSchema),
  });

  async function onSubmit(values: LoginSchema) {
    const { email, password } = values;
    try {
      const result = await signIn({ email, password });
      if (result?.error) {
        toast.error(result.error);
      } else {
        toast.success("Login realizado com sucesso!");
      }
    } catch (error: any) {
      if (error.digest?.startsWith("NEXT_REDIRECT")) {
        throw error;
      }
      console.error("NEXT_AUTH_ERROR", error);
      toast.error("Ocorreu um erro inesperado.");
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-white px-4 w-full">
      <div className="w-full max-w-lg">
        {/* Title */}
        <div className="text-center">
          <h1 className="text-2xl font-bold text-black">Acesso ao Lícito</h1>
        </div>

        {/* Form */}
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="space-y-8 bg-white p-8 rounded-[16px] shadow-md w-full"
          >
            <FormField control={form.control} name="email">
              {({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-black">
                    Email
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        placeholder="Email"
                        type="email"
                        className="h-12 bg-gray-100 border-gray-200 focus:border-gray-300 focus:ring-gray-300 pr-16 rounded-[6px]"
                        {...field}
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-2">
                        <IconMail className="h-4 w-4 text-black" />
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage className="text-sm" />
                </FormItem>
              )}
            </FormField>

            <FormField control={form.control} name="password">
              {({ field }) => (
                <FormItem>
                  <FormLabel className="text-sm font-medium text-black">
                    Password
                  </FormLabel>
                  <FormControl>
                    <div className="relative">
                      <Input
                        placeholder="Password"
                        type="password"
                        className="h-12 bg-gray-100 border-gray-200 focus:border-gray-300 focus:ring-gray-300 pr-16 rounded-[6px]"
                        {...field}
                      />
                      <div className="absolute right-3 top-1/2 transform -translate-y-1/2 flex items-center space-x-2">
                        <IconLock className="h-4 w-4 text-black" />
                      </div>
                    </div>
                  </FormControl>
                  <FormMessage className="text-sm" />
                </FormItem>
              )}
            </FormField>

            <Button
              type="submit"
              disabled={form.formState.isSubmitting}
              className="w-full h-12 text-base font-bold bg-black hover:bg-gray-800 text-white rounded-[6px]"
            >
              {form.formState.isSubmitting && (
                <IconLoader className="mr-2 h-4 w-4 animate-spin" />
              )}
              Login
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
};
